ALTER TABLE verify_proofs
  ALTER COLUMN chain_id TYPE BIGINT;