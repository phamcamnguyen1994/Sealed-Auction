ALTER TABLE computations
DROP COLUMN IF EXISTS output_type;
