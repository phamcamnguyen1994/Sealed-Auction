# Run a benchmark
