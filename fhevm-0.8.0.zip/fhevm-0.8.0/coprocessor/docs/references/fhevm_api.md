# FHEVM API specifications
