# Quick start

For FHEVM-native, to start the setup, you can use our [demo repository](https://github.com/zama-ai/fhevm-L1-demo). Note that, at the time of writing, the demo repository doesn't yet use the FHEVM-native model that is implemented here - instead, it uses the FHEVM-native implementation that uses precompiles (instead of symbolic execution) and FHE computation is done inside geth (as opposed to an external Executor we have here).

For FHEVM-coprocessor, please look at the coprocessor section of the getting started guide.
